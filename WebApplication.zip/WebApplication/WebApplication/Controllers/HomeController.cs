﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication.DAL;

namespace WebApplication.Controllers
{
    public class HomeController : Controller
    {
        private AppDbContext _context;
        public HomeController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            ViewBag.WorkCount = _context.OurWorks.Count();
            return View(_context.OurWorks.Take(4));
        }

        public IActionResult LoadMoreWork(int skip)
        {
            #region Return Json
            //return Json(_context.OurWorks.Select(w=>new
            //{
            //    w.Image
            //}));
            #endregion

            var model = _context.OurWorks.Skip(skip).Take(4);
            return PartialView("_OurWorkPartial", model);

        }
    }
}